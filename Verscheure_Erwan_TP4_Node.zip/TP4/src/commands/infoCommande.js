const { SlashCommandBuilder } = require('discord.js');

module.exports = {
    data: new SlashCommandBuilder()
        .setName('info')
        .setDescription('Affiche des informations sur le serveur ou l\'utilisateur.')
        .addSubcommand(subcommand =>
            subcommand
                .setName('user')
                .setDescription('Affiche des informations sur l\'utilisateur.')
                .addUserOption(option => option.setName('user').setDescription('Utilisateur à consulter (optionnel)'))
        )
        .addSubcommand(subcommand =>
            subcommand
                .setName('server')
                .setDescription('Affiche des informations sur le serveur.')
        ),
    async execute(interaction) {
        if (interaction.options.getSubcommand() === 'user') {
            const userOption = interaction.options.getUser('user');
            const user = userOption ? userOption : interaction.user;
            const member = await interaction.guild.members.fetch(user.id);
            await interaction.reply(`Nom de l'utilisateur : ${user.username}\nDate d'arrivée sur le serveur : ${member.joinedAt}`);
        } else if (interaction.options.getSubcommand() === 'server') {
            const guild = interaction.guild;
            await interaction.reply(`Nom du serveur : ${guild.name}\nNombre de membres : ${guild.memberCount}`);
        }
    },
};
