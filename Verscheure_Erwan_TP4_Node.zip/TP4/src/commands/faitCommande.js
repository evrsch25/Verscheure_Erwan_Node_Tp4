const { SlashCommandBuilder } = require('discord.js');
const axios = require('axios');

module.exports = {
    data: new SlashCommandBuilder()
        .setName('fait')
        .setDescription('Affiche un fait aléatoire.'),
    async execute(interaction) {
        try {
            const response = await axios.get('https://uselessfacts.jsph.pl/random.json?language=en');
            const fact = response.data.text;
            await interaction.reply(fact);
        } catch (error) {
            console.error('Erreur lors de la récupération du fait aléatoire :', error);
            await interaction.reply('Erreur lors de la récupération du fait aléatoire.');
        }
    },
};
