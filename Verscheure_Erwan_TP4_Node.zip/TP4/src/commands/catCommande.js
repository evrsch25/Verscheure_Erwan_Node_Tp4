const { SlashCommandBuilder } = require('discord.js');
const { request } = require('undici');

module.exports = {
    data: new SlashCommandBuilder()
        .setName('cat')
        .setDescription('Affiche une image de chat aléatoire.'),
    async execute(interaction) {
        try {
            const seed = Math.floor(Math.random() * 1000); // Générer une graine aléatoire pour l'image
            const h = 253; // Hauteur de l'image
            const w = 169; // Largeur de l'image
            const file = `https://picsum.photos/seed/${seed}/${h}/${w}`;
            await interaction.reply(file);
        } catch (error) {
            console.error('Erreur lors de la récupération de l\'image de chat :', error);
            await interaction.reply('Erreur lors de la récupération de l\'image de chat.');
        }
    },
};
