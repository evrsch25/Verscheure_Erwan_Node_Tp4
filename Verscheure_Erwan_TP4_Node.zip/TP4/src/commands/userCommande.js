const { SlashCommandBuilder } = require('discord.js');

module.exports = {
    data: new SlashCommandBuilder()
        .setName('user')
        .setDescription('Affiche des informations sur l\'utilisateur.'),
    async execute(interaction) {
        const user = interaction.user;
        const member = await interaction.guild.members.fetch(user.id);
        await interaction.reply(`Nom de l'utilisateur : ${user.username}\nDate d'arrivée sur le serveur : ${member.joinedAt}`);
    },
};
