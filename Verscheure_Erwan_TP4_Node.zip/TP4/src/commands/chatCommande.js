const { SlashCommandBuilder } = require('discord.js');
const { request } = require('undici');

module.exports = {
    data: new SlashCommandBuilder()
        .setName('chat')
        .setDescription('Affiche une image de chat aléatoire.'),
    async execute(interaction) {
        try {
            const chatResult = await request('https://api.thecatapi.com/v1/images/search');
            const data = await chatResult.body.json();
            if (data && data.length > 0) {
                const imageUrl = data[0].url;
                await interaction.reply(imageUrl);
            } else {
                throw new Error('Aucune image de chat trouvée.');
            }
        } catch (error) {
            console.error('Erreur lors de la récupération de l\'image de chat :', error);
            await interaction.reply('Erreur lors de la récupération de l\'image de chat.');
        }
    },
};
