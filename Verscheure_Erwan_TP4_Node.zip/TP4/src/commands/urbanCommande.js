const { SlashCommandBuilder } = require('discord.js');
const { request } = require('undici');

module.exports = {
    data: new SlashCommandBuilder()
        .setName('urban')
        .setDescription('Recherche un terme sur Urban Dictionary.')
        .addStringOption(option =>
            option.setName('terme')
                .setDescription('Le terme à rechercher.')
                .setRequired(true)),
    async execute(interaction) {
        try {
            const terme = interaction.options.getString('terme');
            const urbanResult = await request(`https://api.urbandictionary.com/v0/define?term=${terme}`);
            const { list } = await urbanResult.body.json();
            if (list && list.length > 0) {
                const definition = list[0].definition;
                await interaction.reply(`Terme : ${terme}\nDéfinition : ${definition}`);
            } else {
                await interaction.reply(`Aucune définition trouvée pour le terme : ${terme}`);
            }
        } catch (error) {
            console.error('Erreur lors de la recherche sur Urban Dictionary :', error);
            await interaction.reply('Erreur lors de la recherche sur Urban Dictionary.');
        }
    },
};
