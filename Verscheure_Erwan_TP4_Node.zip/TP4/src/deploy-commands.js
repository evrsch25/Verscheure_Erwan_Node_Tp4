const { REST, Routes } = require('discord.js');
const { clientId, guildId, token } = require('../conf.json');
const fs = require('fs');
const path = require('path');

const commandsPath = path.join(__dirname, 'commands');

const commands = [];
// Récupérer tous les fichiers de commandes du répertoire "commands"
const commandFiles = fs
    .readdirSync(commandsPath)
    .filter((file) => file.endsWith('.js'));

// Récupérer la sortie JSON de SlashCommandBuilder pour chaque commande pour le déploiement
for (const file of commandFiles) {
    const command = require(`${commandsPath}/${file}`);
    commands.push(command.data.toJSON());
}

// Créer une instance de la classe REST pour communiquer avec l'API Discord
const rest = new REST({ version: '10' }).setToken(token);

// Déployer les commandes
(async () => {
    try {
        console.log(
            `Déploiement de ${commands.length} commandes d'application (/).`
        );

        // Utiliser la méthode put pour déployer complètement toutes les commandes dans la guilde avec l'ensemble actuel
        const data = await rest.put(
            // Utiliser les routes pour définir l'emplacement de déploiement des commandes dans la guilde
            // Utiliser les identifiants du client et de la guilde fournis dans le fichier de configuration
            Routes.applicationGuildCommands(clientId, guildId),
            { body: commands }
        );

        console.log(
            `Succès : ${data.length} commandes d'application (/) ont été déployées.`
        );
    } catch (error) {
        // Gérer les erreurs
        console.error('Erreur lors du déploiement des commandes :', error);
    }
})();
