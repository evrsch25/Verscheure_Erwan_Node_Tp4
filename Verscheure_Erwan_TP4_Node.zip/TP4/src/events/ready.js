const { Events } = require('discord.js');

module.exports = {
    event: Events.ClientReady, // Remplacer "name" par "event"
    once: true,
    execute(client) {
        console.log(`Ready! Logged in as ${client.user.tag}`);
    },
};
